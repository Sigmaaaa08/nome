// Online C++ compiler to run C++ program online
#include <iostream>
using namespace std;
int main() {
   int x, y , z;
   cout<< " Digite seus numeros: ";
   cin>> x , y , z ;
   //crescente
   if(x>y>z){
       cout<< z<< "," <<y<< "," <<z<< "\n";
   }

    return 0;
}