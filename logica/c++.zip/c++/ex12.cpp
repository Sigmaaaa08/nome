#include <string>
#include <iostream>
using namespace std;
int main() {
    double hora_trabalhada=0, salario_minimo, salario_bruto ,dependente=0, hora_extra=0, salario, valor_trabalhada, imposto, salario_liquido, grati, novo_salario;
    int num_dependente, num_hora_extra, num_hora_trabalhada; 
    cout<< "Escreva as horas trabalhadas: ";
    cin>> num_hora_trabalhada;
    cout<< "Escreva as horas extras: ";
    cin>> num_hora_extra;
    cout<< "Escreva seu salario minimo: ";
    cin>> salario_minimo;
    cout<< "Escreva seus dependentes: ";
    cin>> num_dependente;
    
    //conta horas trabalhadas:
    hora_trabalhada=hora_trabalhada+num_hora_trabalhada;
    cout<< "Horas trabalhadas : "<<hora_trabalhada<< "\n";
    
    //conta horas extras: 
    hora_extra=(hora_extra+num_hora_extra)*0.5;
    cout<< "Horas extras: "<<hora_extra<<  "\n";
    
    //valor hora trabalhada:
   valor_trabalhada=salario_minimo*0.0333333;
   
   //calcula dependentes:
   dependente=(dependente+num_dependente)*32;
   
   cout<<"Valor horas trabalhada: "<<valor_trabalhada<< "\n";
   
   //valor salario bruto:
   salario_bruto=valor_trabalhada+hora_extra+salario_minimo+dependente;
   cout<< "Salario Bruto: "<<salario_bruto<<  "\n";
   
  //imposto de renda:
  if(salario_bruto>=2000 and salario_bruto<=5000){
      imposto=salario_bruto*0.1;
      cout<< "Imposto a ser pago é de R$" <<imposto<< "\n";
  }
  if(salario_bruto>5000){
      imposto=salario_bruto*0.2;
      cout<< "Imposto a ser pago é de R$" <<imposto<< "\n";
  }
  if(salario_bruto<2000){
      cout<< "N paga imposto";
  }
  
  //salario liquido:
  salario_liquido=salario_bruto-imposto;
  cout<< "\n Salario liquido R$" <<salario_liquido<< "\n";
  
  //gratificação:
  if(salario_bruto<=3500){
      grati=500;
      cout<< "gratificação é de R$500";
      
  }
  if(salario_bruto>3500){
      grati=200;
      cout<< "gratificação é de R$200";
  }
  //salario a receber:
  novo_salario=salario_liquido+grati;
  cout<< "\n O salario que voce recebera é de R$ " <<novo_salario<< "\n";
    return 0;
}
