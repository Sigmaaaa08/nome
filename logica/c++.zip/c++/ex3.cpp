#include <iostream>
#include <string>
using namespace std;
int main() {
 float num1, num2;
  cout << "Digite o primeiro numero: ";
  cin >> num1;
  cout << "Digite o primeiro numero: ";
  cin>> num2;
  if (num1>num2){
      cout<< "O numero maior � " <<num1 << "\n";
  }
  else if (num2>num1){
       cout<< "O numero maior � " <<num2 "\n";
      
  }



  






return 0;
}
